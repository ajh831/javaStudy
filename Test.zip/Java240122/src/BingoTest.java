import static org.junit.Assert.*;

import org.junit.Test;

public class BingoTest {
	static int bingoCount(int[][] bingo) {
		int cnt = 0;
		int garoCnt = 0;
		int seroCnt = 0;
		int crossCnt = 0;
		int crossCnt2 = 0;
		
		// garoCnt
		for (int i = 0; i < bingo.length; i++) {
			for (int j = 0; j < bingo[i].length; j++) {
				if (bingo[i][j] == 1)
					garoCnt++;
			}
			if (garoCnt == 5)
				cnt++;
			garoCnt = 0;
		}
		
//		if (bingo[0][0] == 1) garoCnt++;
//		if (bingo[0][1] == 1) garoCnt++;
//		if (bingo[0][2] == 1) garoCnt++;
//		if (bingo[0][3] == 1) garoCnt++;
//		if (bingo[0][4] == 1) garoCnt++;
//		if(garoCnt==5) cnt++;
		
		// seroCnt
		for (int i = 0; i < bingo.length; i++) {
			for (int j = 0; j < bingo[i].length; j++) {
				if (bingo[j][i] == 1)
					seroCnt++;
			}
			if (seroCnt == 5)
				cnt++;
			seroCnt = 0;
		}
		
		// crossCnt
		for (int i = 0; i < bingo.length; i++) {
			if (bingo[i][i] == 1)
				crossCnt++;
		}
		if (crossCnt == 5)
			cnt++;

		// crossCnt2
//		if (bingo[0][4] == 1) crossCnt++;
//		if (bingo[1][3] == 1) crossCnt++;
//		if (bingo[2][2] == 1) crossCnt++;
//		if (bingo[3][1] == 1) crossCnt++;
//		if (bingo[4][0] == 1) crossCnt++;
		for (int i = 0; i < bingo.length; i++) {
			if (bingo[i][4 - i] == 1)
				crossCnt2++;
		}
		if (crossCnt2 == 5)
			cnt++;
		
		return cnt;
	}
	
	@Test
	public void test99() {
		int[][] bingo = {
				{1,1,1,1,1},
				{1,1,1,1,1},
				{1,1,1,1,1},
				{1,1,1,1,1},
				{1,1,1,1,1},
		};
		assertTrue(bingoCount(bingo)==12);
	}
	
	@Test
	public void test3() {
		int[][] bingo = {
				{1,1,1,1,1},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{1,1,1,1,1},
				{0,0,0,0,0},
		};
		assertTrue(bingoCount(bingo)==2);
	}
	
	@Test
	public void test2() {
		int[][] bingo = {
				{1,1,1,1,1},
				{1,0,0,0,0},
				{1,0,0,0,0},
				{1,0,0,0,0},
				{1,0,0,0,0},
		};
		assertTrue(bingoCount(bingo)==2);
	}
	
	@Test
	public void test1() {
		int[][] bingo = {
				{1,1,1,1,1},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
				};
		assertTrue(bingoCount(bingo)==1);
	}
	
	@Test
	public void test() {
		int[][] bingo = {
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
		};
		assertTrue(bingoCount(bingo)==0);
	}

}
