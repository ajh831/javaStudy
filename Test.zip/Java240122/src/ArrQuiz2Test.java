import static org.junit.Assert.*;

import org.junit.Test;

public class ArrQuiz2Test {
	static int mid(int x, int y, int z) {
		if ((x <= y && y <= z) || (z<=y && y<=x)) {
			return y;
		}
		if ((x <= z && z <= y) || (y<=z && z<=x)) {
			return z;
		}
		return x;
	}
	
	@Test
	public void test() {
		assertTrue(mid(1,2,3)==2);
	}

}
